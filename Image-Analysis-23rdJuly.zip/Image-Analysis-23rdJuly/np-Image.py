import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image   
import requests
from io import BytesIO # bytes io is used for buffer memory to store and capture images


def load_image_from_url(url):
    response = requests.get(url)
    return Image.open(BytesIO(response.content))

elephant_url =  "https://upload.wikimedia.org/wikipedia/commons/3/37/African_Bush_Elephant.jpg"

#elephant_url = "https://m.media-amazon.com/images/I/81JSw5mE54L._UF894,1000_QL80_.jpg"
elephant_image = load_image_from_url(elephant_url)



# display an original image
plt.figure(figsize=(10, 10))
plt.imshow(elephant_image)
plt.title("African Bush Elephant")
plt.axis('off')  # Hide axes
plt.show()

# image to array

# image to array
elephant_np = np.array(elephant_image)
print('Elephant Image shape', elephant_np.shape)



#grey scale image
elephant_gray = elephant_image.convert('L')

plt.figure(figsize=(10,8))
plt.imshow(elephant_gray, cmap='red')
plt.title("Elephant Image in Grey Scale")   
plt.axis('off')  # Hide axes
plt.show()